## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(CVXR)
x <- Variable(2, name = "x")
prob <- Problem(Minimize(sum_squares(x)), list(x >= 1))
opt_val <- psolve(prob, solver = "CLARABEL")
opt_val
value(x)
status(prob)

## -----------------------------------------------------------------------------
result <- solve(prob, solver = "CLARABEL")
result$value
result$status

## -----------------------------------------------------------------------------
installed_solvers()

## ----echo = FALSE-------------------------------------------------------------
check <- "\U2713"
d <- data.frame(
  Solver = c("CLARABEL", "SCS", "OSQP", "HIGHS", "ECOS", "ECOS_BB",
             "GLPK", "GLPK_MI", "CPLEX", "GUROBI", "MOSEK", "CVXOPT",
             "PIQP", "SCIP", "XPRESS"),
  Package = c("clarabel", "scs", "osqp", "highs", "ECOSolveR", "ECOSolveR",
              "Rglpk", "Rglpk", "Rcplex", "gurobi", "Rmosek", "cccp",
              "piqp", "scip", "xpress"),
  LP   = c(check, check, check, check, check, " ", check, check, check, check, check, check, check, check, check),
  QP   = c(check, check, check, check, check, " ", " ", " ", check, check, check, " ", check, " ", check),
  SOCP = c(check, check, " ", " ", check, " ", " ", " ", check, check, check, check, " ", check, check),
  SDP  = c(check, check, " ", " ", " ", " ", " ", " ", " ", " ", check, " ", " ", " ", " "),
  EXP  = c(check, check, " ", " ", " ", " ", " ", " ", " ", " ", check, " ", " ", " ", " "),
  MIP  = c(" ", check, " ", check, " ", check, " ", check, " ", check, check, " ", " ", check, check),
  stringsAsFactors = FALSE
)
knitr::kable(d, align = "lccccccc")

## ----eval = FALSE-------------------------------------------------------------
# psolve(prob, solver = "SCS")

## -----------------------------------------------------------------------------
available_solvers()
exclude_solvers("SCS")
available_solvers()
include_solvers("SCS")

## -----------------------------------------------------------------------------
x <- Variable(pos = TRUE, name = "x")
y <- Variable(pos = TRUE, name = "y")
obj <- Minimize(x * y)
constr <- list(x * y >= 40, x <= 20, y >= 2)
prob <- Problem(obj, constr)
cat("Is DGP:", is_dgp(prob), "\n")
opt_val <- psolve(prob, gp = TRUE, solver = "CLARABEL")
cat("Optimal:", opt_val, " x =", value(x), " y =", value(y), "\n")

## -----------------------------------------------------------------------------
x <- Variable(name = "x")
prob <- Problem(Minimize(ceil_expr(x)), list(x >= 0.7, x <= 1.5))
cat("Is DQCP:", is_dqcp(prob), "\n")
opt_val <- psolve(prob, qcp = TRUE, solver = "CLARABEL")
cat("Optimal:", opt_val, " x =", value(x), "\n")

## -----------------------------------------------------------------------------
n <- 5
x <- Variable(n, name = "x")
lam <- Parameter(nonneg = TRUE, name = "lambda", value = 1.0)

set.seed(42)
A <- matrix(rnorm(10 * n), 10, n)
b <- rnorm(10)

prob <- Problem(Minimize(sum_squares(A %*% x - b) + lam * p_norm(x, 1)))
cat("Is DPP:", is_dpp(prob), "\n")
psolve(prob, solver = "CLARABEL")
value(x)

## -----------------------------------------------------------------------------
value(lam) <- 10.0
psolve(prob, solver = "CLARABEL")
value(x)

## -----------------------------------------------------------------------------
x <- Variable(3, integer = TRUE, name = "x")
prob <- Problem(Minimize(sum(x)), list(x >= 0.5, x <= 3.5))
psolve(prob, solver = "HIGHS")
value(x)

## -----------------------------------------------------------------------------
z <- Variable(2, complex = TRUE, name = "z")
prob <- Problem(Minimize(p_norm(z, 2)), list(z[1] == 1 + 2i))
psolve(prob, solver = "CLARABEL")
value(z)

## -----------------------------------------------------------------------------
b1 <- Variable(boolean = TRUE, name = "b1")
b2 <- Variable(boolean = TRUE, name = "b2")
## implies() returns an Expression; compare with == 1 to make a constraint
prob <- Problem(Maximize(b1 + b2),
                list(implies(b1, b2) == 1, b1 + b2 <= 1))
psolve(prob, solver = "HIGHS")
cat("b1 =", value(b1), " b2 =", value(b2), "\n")

## ----eval = FALSE-------------------------------------------------------------
# pd <- problem_data(prob, solver = "CLARABEL")
# chain <- pd$chain
# 
# # In a loop:
# raw <- solve_via_data(chain, warm_start = FALSE, verbose = FALSE)
# result <- problem_unpack_results(prob, raw$solution, chain, raw$inverse_data)

## -----------------------------------------------------------------------------
x <- Variable(3, name = "x")
prob <- Problem(Minimize(p_norm(x, 1) + sum_squares(x)),
                list(x >= -1, sum(x) == 1))
visualize(prob)

## ----eval = FALSE-------------------------------------------------------------
# visualize(prob, html = "my_problem.html")

## -----------------------------------------------------------------------------
x <- Variable(3, name = "x")
abs(x)     # elementwise absolute value
sqrt(x)    # elementwise square root
sum(x)     # sum of entries
max(x)     # maximum entry
norm(x, "2")  # Euclidean norm

